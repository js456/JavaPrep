package family.model;

public enum Gender {

	MALE,FEMALE
}
