package family.model;

public enum FamilyManagerResult {

	CHILD_ADDITION_SUCCEEDED,CHILD_ADDITION_FAILED,PERSON_NOT_FOUND,NONE;
}
