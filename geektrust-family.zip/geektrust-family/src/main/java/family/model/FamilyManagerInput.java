package family.model;

public enum FamilyManagerInput {
	ADD_CHILD,GET_RELATIONSHIP
}
